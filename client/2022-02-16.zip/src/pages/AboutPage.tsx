import React from 'react';

const AboutPage: React.FC = () => {
  return <div></div>;
};

export default AboutPage;
