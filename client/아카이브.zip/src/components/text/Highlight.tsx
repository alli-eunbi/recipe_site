import styled from 'styled-components';

export const HighLight = styled.span`
  color: darkred;
`;
