import React, { useCallback } from 'react';
import styled, { css } from 'styled-components';
import { Dispatch, SetStateAction } from 'react';

type CheckedObjType = {
  method: string;
  occ: string;
  kind: string;
};

type CatProps = {
  cat: string;
  checkedVal: CheckedObjType;
  onSetChecked: Dispatch<SetStateAction<CheckedObjType>>;
  data: any[];
};

type StyleProps = {
  checked?: boolean;
};

const CategoryTag: React.FC<CatProps> = (props) => {
  const { checkedVal, onSetChecked, data } = props;

  const handleSelectOpt = (e: any) => {
    console.log(e.target);
  };

  return (
    <>
      {data.map((item) => (
        <TagContainer key={item.id}>
          {item.name}
          <TagLabel key={item.id} htmlFor={item.id} onClick={handleSelectOpt}>
            <CheckButton type='radio' name={item.id} id={item.id} />
          </TagLabel>
        </TagContainer>
      ))}
    </>
  );
};

export default CategoryTag;

const TagContainer = styled.div`
  color: white;
  text-align: center;
  font-size: 0.9rem;
  margin: 2px;
  padding: 5px 10px;
  width: fit-content;
  border-radius: 4px;
  background-color: green;
  transition: 150ms ease;
  cursor: pointer;
`;

const TagLabel = styled.label``;

// ${({ checked }: StyleProps) =>
//   checked &&
//   css`
//     background-color: #89c53f;
//     color: black;
//     border: none;
//   `}

const CheckButton = styled.input``;
