import React from 'react';

const Error404: React.FC = () => {
  return <main></main>;
};

export default Error404;
